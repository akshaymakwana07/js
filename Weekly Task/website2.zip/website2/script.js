$(document).ready(function(){
    $("#a1").mouseover(function(){
        $(".a1").slideDown()
    })

    $(document).ready(function(){
        $("#a1").mouseleave(function(){
            $(".a1").slideUp()
        })
    })
})

$(document).ready(function(){
    $("#a2").mousemove(function(){
        $(".a2").slideDown()
    })

    $(document).ready(function(){
        $("#a2").mouseleave(function(){
            $(".a2").slideUp()
        })
    })
})

$(document).ready(function(){
    $("#a3").mousemove(function(){
        $(".a3").slideDown()
    })

    $(document).ready(function(){
        $("#a3").mouseleave(function(){
            $(".a3").slideUp()
        })
    })
})


$(document).ready(function(){
    $("#a4").mousemove(function(){
        $(".a4").slideDown()
    })

    $(document).ready(function(){
        $("#a4").mouseleave(function(){
            $(".a4").slideUp()
        })
    })
})

$(document).ready(function(){
    $("#a5").mousemove(function(){
        $(".a5").slideDown()
    })

    $(document).ready(function(){
        $("#a5").mouseleave(function(){
            $(".a5").slideUp()
        })
    
    $(document).ready(function(){
        $(".frc").mousemove(function(){
            $(".force-2").slideDown()
        })

    $(document).ready(function(){
        $(".frc").mouseleave(function(){
            $(".force-2").slideUp( )
        })
    })    
    })    
    })
})